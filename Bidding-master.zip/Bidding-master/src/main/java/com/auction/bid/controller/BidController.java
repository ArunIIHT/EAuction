package com.auction.bid.controller;

import java.util.List;

import javax.validation.groups.Default;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.auction.bid.model.Bid;
import com.auction.bid.model.BiddingInfo;
import com.auction.bid.service.BidService;
import com.auction.bid.service.ValidationService;

import lombok.AllArgsConstructor;

@RestController
@AllArgsConstructor
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/e-auction/api/v1")
public class BidController {
	
	private BidService bidService;
	
	private ValidationService validationService;
	
	@PostMapping(value="/buyer/place-bid", consumes = {MediaType.APPLICATION_JSON_VALUE}, produces = {MediaType.APPLICATION_JSON_VALUE})
	public ResponseEntity<?> placeBid(@Validated ({Default.class}) @RequestBody Bid bid, BindingResult result) {
		validationService.validate(result);
		Bid bidResponse = bidService.placeBid(bid);
		return new ResponseEntity<Bid>(bidResponse, HttpStatus.CREATED);
	}
	
	@PutMapping(value="/buyer/update-bid", consumes = {MediaType.APPLICATION_JSON_VALUE}, produces = {MediaType.APPLICATION_JSON_VALUE})
	public ResponseEntity<?> updateBid(@Validated ({Default.class})@RequestBody Bid bid) {
		
		List<Bid> bidResponse = bidService.updateBid(bid.getProductId(), bid.getEmail(), bid.getBidAmount());
		return new ResponseEntity<List<Bid>>(bidResponse, HttpStatus.OK);
	}
	
	@GetMapping(value="/buyer/{productId}", consumes = {MediaType.APPLICATION_JSON_VALUE}, produces = {MediaType.APPLICATION_JSON_VALUE})
	public ResponseEntity<?> findBid(@Validated ({Default.class}) @PathVariable(value="productId") String productId) {
		List<Bid> bidResponse = bidService.findByProductId(productId);
		return new ResponseEntity<List<Bid>>(bidResponse, HttpStatus.OK);
	}
	
	@GetMapping(value="/buyer/bidding", consumes = {MediaType.APPLICATION_JSON_VALUE}, produces = {MediaType.APPLICATION_JSON_VALUE})
	public ResponseEntity<?> findAllBid() {
		List<BiddingInfo> bidResponse = bidService.findAllBid();
		return new ResponseEntity<List<BiddingInfo>>(bidResponse, HttpStatus.OK);
	}

}
