package com.auction.bid.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Context;

import org.mapstruct.factory.Mappers;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import com.auction.bid.client.ProductServiceClient;
import com.auction.bid.client.UserServiceClient;
import com.auction.bid.entity.BidEntity;
import com.auction.bid.exception.BiddingException;
import com.auction.bid.mapper.BidMapper;
import com.auction.bid.model.Bid;
import com.auction.bid.model.BiddingInfo;
import com.auction.bid.model.Product;
import com.auction.bid.model.User;
import com.auction.bid.repository.BidRepository;

import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class BidService {
	
	private BidRepository bidRepository;
	
	private ProductServiceClient productServiceClient;
	
	private UserServiceClient userServiceClient;
	
	private MongoTemplate mongoTemplate;
	
	private BidMapper bidMapper = Mappers.getMapper(BidMapper.class);
	
	@Context
	HttpServletRequest request;
	
	
	public Bid placeBid(Bid bid) {
		
		String authorization = request.getHeader("Authorization");
		
		System.out.println("authorization--"+authorization);
		
		List<BidEntity> bidList = bidRepository.findByEmailAndProductId(bid.getEmail(), bid.getProductId());
		if(ObjectUtils.isEmpty(bidList) && bidList.size() == 0) {
			Optional<User> user = Optional.ofNullable(userServiceClient.findUserDetails(authorization, bid.getEmail()));
			if(user.isPresent()) {
				Optional<Product> product = Optional.ofNullable(productServiceClient.findProductDetail(authorization, bid.getProductId()));
				if(product.isPresent()) {
					if(bid.getBiddingDate().isBefore(product.get().getProductBidEndDate())) {
						BidEntity bidResponse = bidRepository.save(bidMapper.convertToEntity(bid));
						return bidMapper.convertToModel(bidResponse);
					}else {
						throw new BiddingException("BID-ERROR", Arrays.asList("Bidding should be placed before bid end date expired"));
					}
				}
			}
		}else {
			throw new BiddingException("BID-ERROR", Arrays.asList("More than one bidding on a product by same user is not allowed"));
		}
		throw new BiddingException("BID-ERROR",Arrays.asList("Exception occure while placing BID"));
	}
	
	public List<Bid> updateBid(String productId, String emailId, Double newBidAmount) {
		
		String authorization = request.getHeader("Authorization");
		
		System.out.println("authorization--"+authorization);
		
		List<BidEntity> bidList = bidRepository.findByEmailAndProductId(emailId, productId);
		if(!ObjectUtils.isEmpty(bidList) && bidList.size() > 0) {
			Optional<Product> product = Optional.ofNullable(productServiceClient.findProductDetail(authorization, productId));
			if(product.isPresent()) {
				List<BidEntity> updateList = new ArrayList<BidEntity>();
				if(LocalDate.now().isBefore(product.get().getProductBidEndDate())
						|| product.get().getProductBidEndDate().isEqual(LocalDate.now())) {
					bidList.stream().filter(filterBid -> filterBid.getProductId().equals(productId))
					.forEach(bid -> {
						bid.setBidAmount(newBidAmount);
						bid.setBiddingDate(LocalDate.now());
						update(bid, newBidAmount);
						updateList.add(bid);
					});
					
					if(!ObjectUtils.isEmpty(updateList)) {
						return bidMapper.convertToModel(updateList);
					}
				}else {
					throw new BiddingException("BID-ERROR", Arrays.asList("Bidding Amount should be update before bid end date expired"));
				}
			}
		}
		throw new BiddingException("BID-ERROR", Arrays.asList("Bid Not Found Exceptiion"));
		
		
	}
	
	public List<Bid> findByProductId(String productId) {
		List<BidEntity> bidEntity = bidRepository.findByProductId(productId);
		if(!ObjectUtils.isEmpty(bidEntity)) {
			return  bidMapper.convertToModel(bidEntity);
		}else {
			//throw new BiddingException("BID-ERROR", Arrays.asList("Bidding not found"));
			return new ArrayList<Bid>();
		}
		
	}
	
	public void update(BidEntity bid, Double newBidAmount) {
		Query query = new Query();
		query.addCriteria(Criteria.where("productId").is(bid.getProductId()));
		Update update = new Update();
		update.set("bidAmount", newBidAmount);
		update.set("biddingDate", LocalDate.now());
		mongoTemplate.upsert(query, update, BidEntity.class);
	}
	
	public List<BiddingInfo> findAllBid() {
		
		List<BiddingInfo> biddingList = new ArrayList<BiddingInfo>();
		
		String authorization = request.getHeader("Authorization");
		
		System.out.println("authorization--"+authorization);
		List<BidEntity> bidEntity = bidRepository.findAll();
		if(!ObjectUtils.isEmpty(bidEntity)) {
			for(BidEntity entity: bidEntity) {
				BiddingInfo bidInfo = new BiddingInfo();
				Bid bid = bidMapper.convertToModel(entity);
				bidInfo.setBid(bid);
				Optional<Product> product = Optional.ofNullable(productServiceClient.findProductDetail(authorization, entity.getProductId()));
				if(product.isPresent()) {
					bidInfo.setProduct(product.get());
					Optional<User> user = Optional.ofNullable(userServiceClient.findUserDetails(authorization, entity.getEmail()));
					if(user.isPresent()) {
						bidInfo.setUser(user.get());
					}
				}
				biddingList.add(bidInfo);
			}
			return biddingList;
		}else {
			//throw new BiddingException("BID-ERROR", Arrays.asList("Bidding not found"));
			return new ArrayList<BiddingInfo>();
		}
		
	}

}
