package com.auction.bid.exception;

import java.util.List;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class ProductException extends RuntimeException {
	
	private String code;
	private List<String> params;

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	public ProductException() {
		super();
	}
	
	public ProductException(String code, List<String> params) {
		super();
		this.code = code;
		this.params = params;
	}

}
