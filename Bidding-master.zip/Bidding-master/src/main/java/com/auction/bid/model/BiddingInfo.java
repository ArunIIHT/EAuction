package com.auction.bid.model;

import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class BiddingInfo {
	
	private Bid bid;
	private Product product;
	private User user;

}
