package com.auction.bid.entity;





import java.time.LocalDate;


import org.springframework.data.mongodb.core.mapping.Document;

import lombok.Data;

@Data
@Document(collection = "product")
public class ProductEntity {
	
	private String productId;
	private String productName;
	private String productShortDesc;
	private String productDetailDesc;
	private String productCategory;
	private Double productStartPrice;
	private LocalDate productBidEndDate;
	private String email;
	

}
