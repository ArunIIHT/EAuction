package com.auction.bid.model;

import java.time.LocalDate;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Positive;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class Product {
	
	@NotNull
	private String productId;
	@NotBlank(message = "productName can't be blank")
	@Size(min = 5, max = 30)
	private String productName;
	private String productShortDesc;
	private String productDetailDesc;
	@NotBlank(message = "category can't be blank")
	@Pattern(regexp = "Painting|Sculptor|Ornament", flags = Pattern.Flag.CASE_INSENSITIVE)
	private String productCategory;
	@Positive
	private Double productStartPrice;
	@NotNull
	@JsonFormat(pattern = "yyyy-MM-dd")
	private LocalDate productBidEndDate;
	@NotNull
	@Email
	private String email;
	

}
