package com.auction.bid.client;

import java.util.Arrays;
import java.util.Optional;

import javax.ws.rs.core.MediaType;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;

import com.auction.bid.exception.ProductException;
import com.auction.bid.model.Product;

@FeignClient(value="ProductServiceClient", url="http://localhost:8083/sellerservice")
public interface ProductServiceClient {
	
	@GetMapping(value="/e-auction/api/v1/seller/product/{productId}", consumes= {MediaType.APPLICATION_JSON}, produces= {MediaType.APPLICATION_JSON})
	ResponseEntity<Product> findByProductId(@RequestHeader(value="Authorization", required = true) String authorization, @PathVariable(value="productId") String productId);
	
	
	default Product findProductDetail(String authorization, String productId) {
		ResponseEntity<Product> productEntity = findByProductId(authorization, productId);
		if(HttpStatus.NO_CONTENT.equals(productEntity.getStatusCode())) {
			throw new ProductException("PRODUCT-ERROR", Arrays.asList("Product not found exception"));
		}
		return getResponseBody(productEntity);
	}
	
	
	public static <T> T getResponseBody(ResponseEntity<T> response){
		return Optional.ofNullable(response).map(ResponseEntity::getBody).orElse(null);
	}
	
	

}
