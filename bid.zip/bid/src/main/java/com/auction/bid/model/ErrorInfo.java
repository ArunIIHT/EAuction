package com.auction.bid.model;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class ErrorInfo {
	
	private String errorRquestUri;
	private List<String> errorMessage;
	private String errorTrace;
	
	

}
