package com.auction.bid.entity;

import java.time.LocalDate;

import org.springframework.data.mongodb.core.mapping.Document;

import lombok.Data;

@Data
@Document(collection="bid")
public class BidEntity {
	
	private Double bidAmount;
	private LocalDate biddingDate;
	private String productId;
	private String email;

}
