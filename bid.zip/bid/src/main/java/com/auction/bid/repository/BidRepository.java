package com.auction.bid.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.auction.bid.entity.BidEntity;

@Repository
public interface BidRepository extends MongoRepository<BidEntity, String>{
	
	List<BidEntity> findByEmail(String emailId);
	
	List<BidEntity> findByProductId(String productId);
	
	List<BidEntity> findByEmailAndProductId(String emailId, String productId);
	
	List<BidEntity> findAll();

}
