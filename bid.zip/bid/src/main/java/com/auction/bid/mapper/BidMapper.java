package com.auction.bid.mapper;

import java.util.List;

import org.mapstruct.Mapper;

import com.auction.bid.entity.BidEntity;
import com.auction.bid.model.Bid;

@Mapper(componentModel = "spring")
public interface BidMapper {
	
	BidEntity convertToEntity(Bid bid);
	Bid convertToModel(BidEntity bidEntity);
	List<Bid> convertToModel(List<BidEntity> bidEntity);

}
