package com.auction.user.service;

import java.util.Arrays;
import java.util.List;

import org.mapstruct.factory.Mappers;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import com.auction.user.entity.UserEntity;
import com.auction.user.exception.UserException;
import com.auction.user.mapper.UserMapper;
import com.auction.user.model.User;
import com.auction.user.repository.UserRepository;

import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class UserService {
	
	private UserRepository userRepository;
	
	private UserMapper userMapper = Mappers.getMapper(UserMapper.class);
	
	public User addUser(User user) {
		UserEntity userRequest = userMapper.convertToEntity(user);
		if(ObjectUtils.isEmpty(userRepository.findByEmail(userRequest.getEmail()))) {
			return userMapper.convertToModel(userRepository.save(userRequest));
		}else {
			throw new UserException("EMAIL-ERROR", Arrays.asList("Email alredy exist"));
		}
	}
	
	public User findUserByEmail(String emailId) {
		UserEntity userEntity = userRepository.findByEmail(emailId);
		if(!ObjectUtils.isEmpty(userEntity)) {
			return userMapper.convertToModel(userEntity);
		}else {
			throw new UserException("USER-ERROR", Arrays.asList("User not found exception"));
		}
	}
	
	public List<User> findAllEmail() {
		List<UserEntity> userEntity = userRepository.findAll();
		if(!ObjectUtils.isEmpty(userEntity)) {
			return userMapper.convertToModelList(userEntity);
		}else {
			throw new UserException("USER-ERROR", Arrays.asList("User not found exception"));
		}
	}
	
	public User findByUserIdAndPassword(String userId, String password){
		UserEntity user = userRepository.findByUserIdAndPassword(userId, password);
	    if(null == user){
	    	throw new UserException("USER-ERROR",Arrays.asList("User not found"));
	    }      
	      return userMapper.convertToModel(user);
	}
	
	public String deleteByEmail(String emailId) {
		userRepository.deleteByEmail(emailId);
		return "The user associated with this email:"+emailId+" was deleted successfully";
		
	}
	

}
