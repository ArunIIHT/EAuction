package com.auction.user.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;
import org.springframework.validation.BindingResult;

import com.auction.user.exception.ValidationException;

@Service
public class ValidationService {
	
	
	public ResponseEntity<?> validate(BindingResult result){
		List<String> errorMessageList = new ArrayList<String>();
		result.getFieldErrors().stream().forEach(error -> {
			String errorMessage = error.getField().toUpperCase(Locale.ENGLISH)+":"+error.getDefaultMessage();
			errorMessageList.add(errorMessage);
		});
		if(!ObjectUtils.isEmpty(errorMessageList)) {
			throw new ValidationException("VALIDATION-ERROR", errorMessageList);
		}
		
		return null;
	}

}
