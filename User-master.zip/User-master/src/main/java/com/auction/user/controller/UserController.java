package com.auction.user.controller;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.validation.groups.Default;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.auction.user.exception.UserException;
import com.auction.user.model.User;
import com.auction.user.service.UserService;
import com.auction.user.service.ValidationService;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import lombok.AllArgsConstructor;

@RestController
@AllArgsConstructor
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/e-auction/api/v1")
public class UserController {
	
	private UserService userService;
	
	private ValidationService validationService;
	
	static final long EXPIRATIONTIME = 90000000;
	
	Map<String, String> tokenMap = null;
	
	@PostMapping(value="/add-user", consumes = {MediaType.APPLICATION_JSON_VALUE}, produces = {MediaType.APPLICATION_JSON_VALUE})
	public ResponseEntity<User> addUer(@Validated ({Default.class}) @RequestBody User userDTO, BindingResult result){
		validationService.validate(result);
		User response = userService.addUser(userDTO);
		return new ResponseEntity<User>(response, HttpStatus.CREATED);
	}
	
	@GetMapping(value="/email/{emailId}", consumes = {MediaType.APPLICATION_JSON_VALUE}, produces = {MediaType.APPLICATION_JSON_VALUE})
	public ResponseEntity<User> findByEmail(@Validated ({Default.class}) @PathVariable(value="emailId") String emailId){
		User response = userService.findUserByEmail(emailId);
		return new ResponseEntity<User>(response, HttpStatus.OK);
	}
	
	@DeleteMapping(value="/email/{emailId}", consumes = {MediaType.APPLICATION_JSON_VALUE}, produces = {MediaType.APPLICATION_JSON_VALUE})
	public ResponseEntity<String> deleteByEmail(@Validated ({Default.class}) @PathVariable(value="emailId") String emailId){
		String message = userService.deleteByEmail(emailId);
		return new ResponseEntity<String>(message, HttpStatus.OK);
	}
	
	@GetMapping(value="/email", consumes = {MediaType.APPLICATION_JSON_VALUE}, produces = {MediaType.APPLICATION_JSON_VALUE})
	public ResponseEntity<List<User>> findAllEmail(){
		List<User> response = userService.findAllEmail();
		return new ResponseEntity<List<User>>(response, HttpStatus.OK);
	}
	
	@PostMapping(value="/login", consumes = {MediaType.APPLICATION_JSON_VALUE}, produces = {MediaType.APPLICATION_JSON_VALUE})
	public ResponseEntity<Map<String, String>> login(@RequestBody User user){
		String jwtToken = "";
		User userObj = null;
		try{
			userObj = userService.findByUserIdAndPassword(user.getUserId(), user.getPassword());
			if(null != user){
				tokenMap = new HashMap<String,String>();
				jwtToken = getToken(user.getUserId(), userObj.getFirstName());
				System.out.println("token======"+jwtToken);
				tokenMap.clear();
				tokenMap.put("token", jwtToken);
				tokenMap.put("userId", userObj.getUserId());
				tokenMap.put("userName", userObj.getFirstName());
				tokenMap.put("emailId", userObj.getEmail());
				tokenMap.put("message", "Successfully logged in");
			}
		}catch(UserException excep){
			tokenMap = new HashMap<String,String>();
			tokenMap.clear();
			tokenMap.put("token", null);
			tokenMap.put("message",  "Login user "+user.getUserId()+" is not avaialble in system. Please register");
			return new ResponseEntity<>(tokenMap, HttpStatus.UNAUTHORIZED);
		}catch(Exception excep){
			tokenMap = new HashMap<String,String>();
			tokenMap.clear();
			tokenMap.put("token", null);
			tokenMap.put("message",  "");
			return new ResponseEntity<>(tokenMap, HttpStatus.UNAUTHORIZED);
		}
		return new ResponseEntity<Map<String, String>>(tokenMap, HttpStatus.OK);
	}





	// Generate JWT token
		public String getToken(String username, String password) throws Exception {
			if(username == null || password == null){
				throw new ServletException("fill user detail");
			}		
			 String token = Jwts.builder().setSubject(username)
			.setIssuedAt(new Date())
			.setExpiration(new Date(System.currentTimeMillis()+EXPIRATIONTIME))
			.signWith(SignatureAlgorithm.HS256, "secretkey")
			.compact();
	        return token;       
		}

}
