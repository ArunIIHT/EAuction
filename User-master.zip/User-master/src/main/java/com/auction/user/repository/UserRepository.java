package com.auction.user.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.auction.user.entity.UserEntity;

@Repository
public interface UserRepository extends MongoRepository<UserEntity, String> {
	
	UserEntity findByEmail(String emailId);
	
	UserEntity findByUserIdAndPassword(String userId, String userPassword);
	
	void deleteByEmail(String emailId);

}
