package com.auction.user;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UseUserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
