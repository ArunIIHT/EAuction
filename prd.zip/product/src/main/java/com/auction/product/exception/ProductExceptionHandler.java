package com.auction.product.exception;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.auction.product.model.ErrorInfo;

import lombok.AllArgsConstructor;

@ControllerAdvice
@AllArgsConstructor
public class ProductExceptionHandler {
	
	
	
	@ExceptionHandler(ProductException.class)
	public ResponseEntity<ErrorInfo> handleProductException(ProductException e, HttpServletRequest request){
		StringWriter sw = new StringWriter();
		e.printStackTrace(new PrintWriter(sw));
		List<String> errorList = !CollectionUtils.isEmpty(e.getParams()) ? e.getParams() : new ArrayList<String>();
		ErrorInfo dto = new ErrorInfo(request.getRequestURI(), errorList, sw.toString());
		return new ResponseEntity<ErrorInfo>(dto, HttpStatus.NO_CONTENT);
	}
	
	@ExceptionHandler(ValidationException.class)
	public ResponseEntity<ErrorInfo> handleValidationException(ValidationException e, HttpServletRequest request){
		StringWriter sw = new StringWriter();
		e.printStackTrace(new PrintWriter(sw));
		List<String> errorList = !CollectionUtils.isEmpty(e.getParams()) ? e.getParams() : new ArrayList<String>();
		ErrorInfo dto = new ErrorInfo(request.getRequestURI(), errorList, sw.toString());
		return new ResponseEntity<ErrorInfo>(dto, HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	@ExceptionHandler(UserException.class)
	public ResponseEntity<ErrorInfo> handleUserException(UserException e, HttpServletRequest request){
		StringWriter sw = new StringWriter();
		e.printStackTrace(new PrintWriter(sw));
		List<String> errorList = !CollectionUtils.isEmpty(e.getParams()) ? e.getParams() : new ArrayList<String>();
		ErrorInfo dto = new ErrorInfo(request.getRequestURI(), errorList, sw.toString());
		return new ResponseEntity<ErrorInfo>(dto, HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	@ExceptionHandler(BiddingException.class)
	public ResponseEntity<ErrorInfo> handleBiddingException(BiddingException e, HttpServletRequest request){
		StringWriter sw = new StringWriter();
		e.printStackTrace(new PrintWriter(sw));
		List<String> errorList = !CollectionUtils.isEmpty(e.getParams()) ? e.getParams() : new ArrayList<String>();
		ErrorInfo dto = new ErrorInfo(request.getRequestURI(), errorList, sw.toString());
		return new ResponseEntity<ErrorInfo>(dto, HttpStatus.INTERNAL_SERVER_ERROR);
	}



}
