package com.auction.product.client;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;

import com.auction.product.exception.UserException;
import com.auction.product.model.Bid;

@FeignClient(value="BiddingServiceClient", url="http://localhost:8084/bidservice")
public interface BidServiceClient {
	
	@GetMapping(value="/e-auction/api/v1/buyer/{productId}", 
			consumes= {MediaType.APPLICATION_JSON_VALUE}, produces= {MediaType.APPLICATION_JSON_VALUE})
 	ResponseEntity<List<Bid>> findByProductId(@RequestHeader(value="Authorization", required = true) String authorization, @PathVariable(value="productId") String productId);
	
	
	default List<Bid> findBidDetails(String authorization,  String productId) {
		ResponseEntity<List<Bid>> bid = findByProductId(authorization, productId);
		if(HttpStatus.NO_CONTENT.equals(bid.getStatusCode())) {
			throw new UserException("BID-ERROR", Arrays.asList("Bid not found exception"));
		}
		return getResponseBody(bid);
	}
	
	public static <T> T getResponseBody(ResponseEntity<T> response){
		return Optional.ofNullable(response).map(ResponseEntity::getBody).orElse(null);
	}

}
