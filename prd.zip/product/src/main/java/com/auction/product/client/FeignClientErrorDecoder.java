package com.auction.product.client;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.boot.configurationprocessor.json.JSONException;
import org.springframework.boot.configurationprocessor.json.JSONObject;
import org.springframework.http.HttpStatus;

import com.auction.product.exception.AuctionRunTimeException;

import feign.Response;
import feign.codec.ErrorDecoder;

public class FeignClientErrorDecoder implements ErrorDecoder{
	
	ErrorDecoder decoder = new Default();

	@Override
	public Exception decode(String methodKey, Response response) {
		
		try {
			
			String responseMessage = new BufferedReader(response.body().asReader(StandardCharsets.UTF_8)).lines()
			.collect(Collectors.joining("\n"));
			
			JSONObject jsonObject = new JSONObject(responseMessage);
			
			if(response.status() == HttpStatus.BAD_REQUEST.value()) {
				
			}else if(response.status() >= 500 && response.status() <= 599) {
				String errorMessage = Optional.ofNullable(jsonObject.getString("errorMessage")).filter(org.apache.commons.lang.StringUtils::isNotBlank)
				.orElse(responseMessage);
				
				throw new AuctionRunTimeException(response.status()+"", new Throwable(errorMessage));
			}
			
		}catch(IOException | JSONException e) {
			throw new AuctionRunTimeException(response.status()+"", new Throwable(e));
		}
		return decoder.decode(methodKey, response);
	}

}
