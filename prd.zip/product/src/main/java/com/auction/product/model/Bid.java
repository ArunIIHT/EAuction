package com.auction.product.model;

import java.time.LocalDate;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Positive;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class Bid {
	
	@Positive
	private Double bidAmount;
	@JsonFormat(pattern = "yyyy-MM-dd")
	private LocalDate biddingDate;
	@NotNull
	private String productId;
	@NotNull
	@Email
	private String email;

}
