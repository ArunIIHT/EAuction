package com.auction.product.config;

//import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
//import org.springframework.security.config.http.SessionCreationPolicy;
//import org.springframework.security.web.SecurityFilterChain;
//import org.springframework.context.annotation.Bean;
//import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
//import org.springframework.security.config.annotation.web.builders.HttpSecurity;

//@EnableWebSecurity
//@EnableGlobalMethodSecurity(prePostEnabled = true)
public class SecurityConfig{
	
	// @Bean

//	    public SecurityFilterChain filterChain(HttpSecurity httpSecurity) throws Exception {
//
//	        httpSecurity.cors().and().csrf().disable()
//	        .sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS).and()
//
//            .authorizeRequests()
//
//            .antMatchers("/e-auction/api/**").permitAll()
//
//            .antMatchers("/h2-console/**").permitAll()
//
//            .antMatchers("/swagger-ui/**").permitAll()
//
//            .antMatchers("/swagger-ui/**", "/v3/api-docs/**").permitAll()
//
//            .anyRequest().authenticated();
//	        httpSecurity.headers().frameOptions().disable();
//	        return httpSecurity.build();
//
//	 }

}
