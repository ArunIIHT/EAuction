package com.auction.user.mapper;

import java.util.List;

import org.mapstruct.Mapper;

import com.auction.user.entity.UserEntity;
import com.auction.user.model.User;

@Mapper(componentModel = "spring")
public interface UserMapper {
	
	UserEntity convertToEntity(User user);
	User convertToModel(UserEntity userEntity);
	
	List<User> convertToModelList(List<UserEntity> userEntity);

}
