package com.auction.user.listener;

import java.io.IOException;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.TextMessage;

import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

import com.auction.user.model.User;
import com.auction.user.service.UserService;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.AllArgsConstructor;

@Component
@AllArgsConstructor
public class UserListener {
	
	private UserService userService;
	
	@JmsListener(destination="user.queue")
	public void recieveUserMessage(Message message) {
		if(message instanceof TextMessage) {
			ObjectMapper mapper  = new ObjectMapper();
			try {
				User user = mapper.readValue(((TextMessage) message).getText().getBytes(), User.class);
				System.out.println(user);
				userService.addUser(user);
			} catch (IOException | JMSException e) {
				e.printStackTrace();
			}
			
		}
		
	}
	

}
