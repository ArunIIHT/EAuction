package com.auction.user.model;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class User {
	
	@NotEmpty(message = "firstName can't be blank")
	@Size(min = 5, max = 30)
	private String firstName;
	@NotEmpty(message = "lastName can't be blank")
	@Size(min = 5, max = 25)
	private String lastName;
	private String address;
	private String city;
	private String state;
	private Integer pin;
	@NotBlank(message = "phone can't be blank")
	@Size(min = 10, max = 10)
	@Pattern(regexp = "\\d{10}|(?:\\d{3}-){2}\\d{4}|\\(\\d{3}\\)\\d{3}-?\\d{4}")
	private String phone;
	@NotNull
	@Email
	private String email;
	@NotNull
	private String userId;
	@NotNull
	private String password;

}
