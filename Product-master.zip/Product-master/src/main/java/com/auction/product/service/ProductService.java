package com.auction.product.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import javax.servlet.ServletContext;
import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Context;

import org.mapstruct.factory.Mappers;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import com.auction.product.client.BidServiceClient;
import com.auction.product.client.UserServiceClient;
import com.auction.product.entity.ProductEntity;
import com.auction.product.exception.BiddingException;
import com.auction.product.exception.ProductException;
import com.auction.product.mapper.ProductMapper;
import com.auction.product.model.Bid;
import com.auction.product.model.BiddingInfo;
import com.auction.product.model.Product;
import com.auction.product.model.User;
import com.auction.product.repository.ProductRepository;

import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class ProductService {
	
	private ProductRepository productRepository;
	
	private UserServiceClient userServiceClient;
	
	private BidServiceClient bidServiceClient;
	
	@Context
	HttpServletRequest request;
	
	
	private ProductMapper productMapper = Mappers.getMapper(ProductMapper.class);
	
	public Product addProduct(Product product) {
		
		String authorization = request.getHeader("Authorization");
		
		System.out.println("authorization--"+authorization);
		
		User userEntity = userServiceClient.findUserDetails(product.getEmail(), authorization);
		
		if(!ObjectUtils.isEmpty(userEntity)) {
			if(product.getProductBidEndDate().isAfter(LocalDate.now())) {
				ProductEntity productRequest = productMapper.convertToEntity(product);
				ProductEntity productResponse = productRepository.save(productRequest);
				if(!ObjectUtils.isEmpty(productResponse)) {
					return productMapper.convertToModel(productResponse);
				}
			}else {
				throw new ProductException("PRODUCT-BID-DATE", Arrays.asList("Bid end date should be future date"));
			}
			
		}
		throw new ProductException("PROD-ERROR", Arrays.asList("Exception while saving product"));
	}
	
	
	public Boolean deleteProduct(String productId) {
		ProductEntity product = productRepository.findByProductId(productId);
		String authorization = request.getHeader("Authorization");
		
		System.out.println("authorization--"+authorization);
		
		if(!ObjectUtils.isEmpty(product)) {
			if(LocalDate.now().isAfter(product.getProductBidEndDate())) {
				throw new ProductException("PRODUCT-ERROR", Arrays.asList("Product should not be delete after bid end date"));
			}
			
			if(!ObjectUtils.isEmpty(bidServiceClient.findBidDetails(authorization, productId))) {
				throw new BiddingException("BID-ERROR", Arrays.asList("Product couldn't delete because bid is placed"));
			}
			
			productRepository.deleteByProductId(productId);
			return true;
		}else {
			throw new ProductException("PRODUCT-ERROR", Arrays.asList("Product not found exception"));
		}
	}
	
	public Product findProduct(String productId) {
		ProductEntity product = productRepository.findByProductId(productId);
		if(!ObjectUtils.isEmpty(product)) {
			return productMapper.convertToModel(product);
		}else {
			throw new ProductException("PRODUCT-ERROR", Arrays.asList("Product not found exception"));
		}
	}
	
	public List<Product> getAllProduct() {
		List<ProductEntity> product = productRepository.findAll();
		if(!ObjectUtils.isEmpty(product)) {
			return productMapper.convertToModelList(product);
		}else {
			throw new ProductException("PRODUCT-ERROR", Arrays.asList("Product not found exception"));
		}
	}
	
	
	public List<BiddingInfo> showBiddingInfo(String productId) {
		String authorization = request.getHeader("Authorization");
		
		System.out.println("authorization--"+authorization);
		List<Bid> bidList = bidServiceClient.findBidDetails(authorization, productId);
		ProductEntity product = productRepository.findByProductId(productId);
		if(!ObjectUtils.isEmpty(product)) {
			List<BiddingInfo> biddingList = new ArrayList<BiddingInfo>();
			bidList.stream().forEach(bid-> {
				BiddingInfo bidInfo = new BiddingInfo();
				bidInfo.setBidAmount(bid.getBidAmount());
				bidInfo.setBiddingDate(bid.getBiddingDate());
				bidInfo.setProductShortDesc(product.getProductShortDesc());
				bidInfo.setProductDetailDesc(product.getProductDetailDesc());
				bidInfo.setProductCategory(product.getProductCategory());
				bidInfo.setProductStartPrice(product.getProductStartPrice());
				bidInfo.setProductBidEndDate(product.getProductBidEndDate());
				biddingList.add(bidInfo);
			});
			
			return biddingList.stream().sorted(Comparator.comparing(BiddingInfo::getBidAmount, Comparator.reverseOrder())).collect(Collectors.toList());
		}else {
			throw new ProductException("PRODUCT-ERROR", Arrays.asList("Product not found exception"));
		}
	}
	
	

}
