package com.auction.product.model;

import java.time.LocalDate;

import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class BiddingInfo {
	
	private String productShortDesc;
	private String productDetailDesc;
	private String productCategory;
	private Double productStartPrice;
	private LocalDate productBidEndDate;
	private Double bidAmount;
	private LocalDate biddingDate;

}
