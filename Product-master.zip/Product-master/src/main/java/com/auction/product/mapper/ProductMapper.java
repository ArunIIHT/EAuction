package com.auction.product.mapper;

import java.util.List;

import org.mapstruct.Mapper;

import com.auction.product.entity.ProductEntity;
import com.auction.product.model.Product;

@Mapper(componentModel = "spring")
public interface ProductMapper {
	
	ProductEntity convertToEntity(Product product);
	Product convertToModel(ProductEntity productEntity);
	
	List<Product> convertToModelList(List<ProductEntity> productEntity);

}
