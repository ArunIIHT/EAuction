package com.auction.product.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.groups.Default;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.auction.product.model.BiddingInfo;
import com.auction.product.model.Product;
import com.auction.product.service.ProductService;
import com.auction.product.service.ValidationService;

import lombok.AllArgsConstructor;

@RestController
@AllArgsConstructor
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/e-auction/api/v1")
public class SellerController {
		
	private ProductService  productService;
	
	private ValidationService validationService;
	
	@PostMapping(value="/seller/add/product", consumes = {MediaType.APPLICATION_JSON_VALUE}, produces = {MediaType.APPLICATION_JSON_VALUE})
	public ResponseEntity<?> addProduct(@Validated ({Default.class}) @RequestBody Product product, BindingResult result){
		validationService.validate(result);
		Product productResponse = productService.addProduct(product);
		return new ResponseEntity<Product>(productResponse, HttpStatus.CREATED);
	}
	
	@DeleteMapping(value="/seller/delete/{productId}", consumes = {MediaType.APPLICATION_JSON_VALUE}, produces = {MediaType.APPLICATION_JSON_VALUE})
	public ResponseEntity<?> deleteProduct(@Validated ({Default.class}) @PathVariable(value= "productId", required=true) String productId){
		Boolean value  = productService.deleteProduct(productId);
		return new ResponseEntity<Boolean>(value, HttpStatus.OK);
	}
	
	@GetMapping(value="/seller/product/{productId}", consumes = {MediaType.APPLICATION_JSON_VALUE}, produces = {MediaType.APPLICATION_JSON_VALUE})
	public ResponseEntity<?> findProduct(@Validated ({Default.class}) @PathVariable(value= "productId", required=true) String productId){
		Product product = productService.findProduct(productId);
		return new ResponseEntity<Product>(product, HttpStatus.OK);
	}
	
	@GetMapping(value="/seller/show-bids/{productId}", consumes = {MediaType.APPLICATION_JSON_VALUE}, produces = {MediaType.APPLICATION_JSON_VALUE})
	public ResponseEntity<?> showBiddingInfo(@Validated ({Default.class}) @PathVariable(value= "productId", required=true) String productId){
		List<BiddingInfo> biddingInfo = productService.showBiddingInfo(productId);
		return new ResponseEntity<List<BiddingInfo>>(biddingInfo, HttpStatus.OK);
	}
	
	@GetMapping(value="/seller/product", consumes = {MediaType.APPLICATION_JSON_VALUE}, produces = {MediaType.APPLICATION_JSON_VALUE})
	public ResponseEntity<?> getAllProduct(){
		List<Product> product = productService.getAllProduct();
		return new ResponseEntity<List<Product>>(product, HttpStatus.OK);
	}
	
}
