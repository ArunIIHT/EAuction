package com.auction.product.exception;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class AuctionRunTimeException extends RuntimeException {
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	public AuctionRunTimeException() {
		super();
	}
	
	public AuctionRunTimeException(String message, Throwable error) {
		super(message, error);
	}
	
	public AuctionRunTimeException(Throwable error) {
		super(error);
	}


}
