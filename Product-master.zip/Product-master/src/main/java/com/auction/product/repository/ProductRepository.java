package com.auction.product.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.auction.product.entity.ProductEntity;

@Repository
public interface ProductRepository extends MongoRepository<ProductEntity, String>{
	
	public ProductEntity findByProductId(String productId);
	
	public void deleteByProductId(String productId);
	
	public List<ProductEntity> findAll();
	
	
}
