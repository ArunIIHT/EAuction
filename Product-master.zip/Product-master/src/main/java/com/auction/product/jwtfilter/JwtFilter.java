package com.auction.product.jwtfilter;


import java.io.IOException;
import java.util.Enumeration;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Component;
import org.springframework.web.filter.GenericFilterBean;
import org.springframework.web.filter.OncePerRequestFilter;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureException;



/* This class implements the custom filter by extending org.springframework.web.filter.GenericFilterBean.  
 * Override the doFilter method with ServletRequest, ServletResponse and FilterChain.
 * This is used to authorize the API access for the application.
 */

@Component
public class JwtFilter extends GenericFilterBean {

//	@Override
//	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
//			throws ServletException, IOException {
//		
//		String auth = request.getHeader("Authorization");
//		
//		System.out.println("Authorization--"+auth);
//		
//		Object attribute = request.getAttribute("Authorization");
//		
//		System.out.println(attribute);
//		
//		
//		Enumeration<String> enumer = request.getAttributeNames();
//		
//		while (enumer.hasMoreElements()) {
//			String key = enumer.nextElement();
//			System.out.println(key);
//		
//		}
//		
//		final String token = auth.substring(7);
//	
//				try {
//					final Claims claims = Jwts.parser().setSigningKey("secretkey").parseClaimsJws(token).getBody();
//					request.setAttribute("claims", claims);
//					
//				} catch (final SignatureException e) {
//					throw new ServletException("Invalid token");
//				}
//				
//				filterChain.doFilter(request, response);
//		
//	}

	
	
	

	/*
	 * Override the doFilter method of GenericFilterBean.
     * Retrieve the "authorization" header from the HttpServletRequest object.
     * Retrieve the "Bearer" token from "authorization" header.
     * If authorization header is invalid, throw Exception with message. 
     * Parse the JWT token and get claims from the token using the secret key
     * Set the request attribute with the retrieved claims
     * Call FilterChain object's doFilter() method */
	
	
	@Override
    public void doFilter(final ServletRequest req, final ServletResponse res, final FilterChain chain)
			throws IOException, ServletException {

		final HttpServletRequest request = (HttpServletRequest) req;
		
	
		
//		Enumeration<String> getHeaderNames = request.getHeaderNames();
//		
//		while(getHeaderNames.hasMoreElements()) {
//			System.out.println("getHeaderNames--"+getHeaderNames.nextElement());
//			
//			Enumeration<String> getHeaders = request.getHeaders(getHeaderNames.nextElement());
//			
//			while(getHeaders.hasMoreElements()) {
//				System.out.println("getHeaders--"+getHeaders.nextElement());
//			}
//			
//		}
		
//		Enumeration<String> getHeaders = request.getHeaders("Authorization");
//		while(getHeaders.hasMoreElements()) {
//			System.out.println("getHeaders--"+getHeaders.nextElement());
//		}
		
		
		
		final HttpServletResponse response = (HttpServletResponse) res;		
		 response.setHeader("Access-Control-Allow-Origin", "*");
	        response.setHeader("Access-Control-Allow-Methods", "GET,POST,DELETE,PUT,OPTIONS");
	        response.setHeader("Access-Control-Allow-Headers", "*");
	       // response.setHeader("Content-Type", "application/json");
	      //  response.setHeader("Access-Control-Allow-Headers", "Authorization");
	      response.setHeader("Access-Control-Allow-Credentials", "true");
		final String authHeader = request.getHeader("Authorization");
		final String methodType = request.getMethod();
		final String servletPath = request.getServletPath();
		
				
				if(!methodType.equalsIgnoreCase("OPTIONS")&& (!servletPath.contains("/api/v1/login") && !servletPath.contains("/api/v1/add-user"))){
	
					if (authHeader == null || !authHeader.startsWith("Bearer ")) {
						throw new ServletException("Invalid Authorization header");
					}
		
					final String token = authHeader.substring(7);
		
					try {
						final Claims claims = Jwts.parser().setSigningKey("secretkey").parseClaimsJws(token).getBody();
						request.setAttribute("claims", claims);
					} catch (final SignatureException e) {
						throw new ServletException("Invalid token");
					}
		
					
			}
				chain.doFilter(req, res);
		}
	
}
